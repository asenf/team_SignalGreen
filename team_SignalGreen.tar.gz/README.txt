Signal Green Simulator v3.0 25/03/2015
--------------------------------------


CONTENTS:	* DESCRIPTION
		* AUTHORS
		* INSTALLATION
		* HOW TO RUN
		* UNINSTALL
		* DEPENDENCIES
		* KNOWN ISSUES

DESCRIPTION:	This package contains the environment and executable
		files to run the Signal Green Simulator v3.1 (SG).
		SG is part of the Group Project 7CCSMGPR Term 2 2015
		submission @King's College London, UK.

AUTHORS:	1117649	Aziz, Waqar Ali		waqar.aziz@kcl.ac.uk
		1456656	Strigini, Yoann Herve	yoann.strigini@kcl.ac.uk
		1459362	Senf, Andrea Kay	andrea.senf@kcl.ac.uk
		1466371	Saalim, Adeela Wazir	adeela.saalim@kcl.ac.uk
		1471266	Kerr, James William	james.kerr@kcl.ac.uk
				
INSTALLATION:	Double-click on the SignalGreen_v3.1_setup.jar and follow the instructions
		to extract the Signal Green Simulator and the Repast libraries:
		1. Select Language [eng]
		2. Press Next
		3. Press Next
		4. Accept license agreement.
		5. Select installation path. Make sure you select a local folder
			and the folder is writeable, e.g. C:\SG3.1\
		6. Leave checkboxes as they are. It will install the Repast core files
			the SG source code, and the SG Javadoc. Press Next
		7.  The installation should take from few seconds to one or two minutes
		8. Press Next or uncheck if you do not want a shortcut in the start menu
		9. Press Done.
		
		The installation includes an uninstaller.jar package.
				
HOW TO RUN:     Windows: Navigate to the project root folder and double click
		the start_model.bat launcher.
		*nix: at the command prompt type: $ ./start_model.command
		It should take a few seconds to load the model.

UNINSTALL:	Either use the uninstaller.jar or delete the project folder.

DEPENDENCIES:	Java version: JVM 7 required.
		SG has been tested successfully on various 32/64-bit 
		Windows 7 machines. It also runs under *nix.

KNOWN ISSUES:	'UNC paths are not supported.' error shown in case the simulator 
		is run from network folders. Either move it to a local folder, or
		use the following commands:
			prompt> pushd \\your_network_location\SignalGreen_root_folder\
			prompt> start_model.bat


EOF